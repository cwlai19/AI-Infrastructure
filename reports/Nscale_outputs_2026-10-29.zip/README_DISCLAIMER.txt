Created by Christina W. Lai as of 29 October 2026. AI tool used: Claude (Anthropic). For information and discussion only; not investment, credit or legal advice. Based on public sources as cited; may contain errors or omissions and has not been independently verified. No representation or warranty is given, and the author accepts no liability for any reliance placed on it.

Contents are drawn from public sources as cited in each file (SEC filings, UK Companies House, lender and counterparty filings, news). Grades: A = filing or registry, B = company release or aggregator, C = news or our own estimate. 'Credit read' and construction-risk ratings are the author's judgement.

Open the .html files in any web browser (the map needs an internet connection for its outlines).
