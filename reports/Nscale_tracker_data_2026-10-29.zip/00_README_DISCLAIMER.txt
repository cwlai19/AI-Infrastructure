Created by Christina W. Lai as of 29 October 2026. AI tool used: Claude (Anthropic). For information and discussion only; not investment, credit or legal advice. Based on public sources as cited; may contain errors or omissions and has not been independently verified. No representation or warranty is given, and the author accepts no liability for any reliance placed on it.

Contents are drawn from public sources as cited in each file (SEC filings, UK Companies House, lender and counterparty filings, news). Grades: A = filing or registry, B = company release or aggregator, C = news or our own estimate. 'Credit read' and construction-risk ratings are the author's judgement.

Nscale credit tracker: full data export (generated from the statement files in the GitHub repo)
Statements: one row per fact. Each fact has a source document, location in that document, the date it was true
(effective_date), the date we recorded it (observed_date), how it was obtained (method) and a grade (A/B/C).
Grades: A = filing, registry, rating agency or a lender's/counterparty's own filing; B = company press or an aggregator
(e.g. CCIR), or an A source seen only as an excerpt; C = news, analysts, our own estimates.
review_verdict: 'rejected' = kept on file but not used (our misreading); 'explained' = known, understood disagreement.
Debt_ledger: the value shown for each facility after applying the resolution rules (latest date, then strongest source).
Customer_contracts / Leases / Sites / Counterparty_dependence: resolved values per contract, lease, campus and counterparty, with grade.
Debt_terms_if_late: per loan, the completion deadline, what happens if the customer walks, cash traps, reserves and parent support.
Credit reads and construction-risk ratings are analyst judgement and live in the site map, not here.
Events: the daily monitor's log of new SEC and Companies House filings naming Nscale (status new / baseline / ignored).
